import * as DATA from '../actionTypes/User';

export function getData() {
  return {
    type: DATA.GET_DATA,
  };
}
export function getDataSuccess(data) {
  return {
    type: DATA.GET_DATA_SUCCESS,
    data,
  };
}

export function getDataFailure(error) {
  return {
    type: DATA.GET_DATA_FAILURE,
    error,
  };
}

export function addData(data) {
  return {
    type: DATA.ADD_DATA,
    data,
  };
}

export function getContactsSucccess(contacts) {
  return {
    type: DATA.ADD_DATA_SUCCESS,
    contacts,
  };
}

export function getContactsFailure(error) {
  return {
    type: DATA.ADD_DATA_FAILURE,
    error,
  };
}
