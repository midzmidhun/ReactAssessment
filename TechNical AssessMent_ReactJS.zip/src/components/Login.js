import React from 'react';
import PropTypes from 'prop-types';
import { Button, Form, FormGroup, Label, Input, Row, Col } from 'reactstrap';

class Login extends React.PureComponent {
	constructor(props) {
		super(props);
		this.state = {
			username: '',
			password: '',
		};
	}

	handleInputData = (event) => {
		const { target: { name, value } } = event;
		this.setState({ [name]: value, });
	}

	handleSubmit = (event) => {
		event.preventDefault();
		const { username, password } = this.state;
		const data = { username, password };
		this.props.handleSubmitData(data);
		this.setState({ password: '', username: '' });
	}

	render() {
		return (
			<Form onSubmit={this.handleSubmit} className="mainsection">
				<h3>Login Form</h3>
				<Row>
					<Col xs="6" sm="4">
						<FormGroup>
							<Label for="userName">UserName</Label>
							<Input type="text" required name="username" id="userName" onChange={(e) => this.handleInputData(e)} value={this.state.username} placeholder="" />
						</FormGroup>
					</Col>
				</Row>
				<Row>
					<Col xs="6" sm="4">
						<FormGroup>
							<Label for="password">Password</Label>
							<Input type="password" required name="password" id="password" onChange={(e) => this.handleInputData(e)} value={this.state.password} placeholder="" />
						</FormGroup>
					</Col>
				</Row>
				<Button type="submit">Login</Button> &nbsp;
        <a href="/">Register</a>
			</Form>
		);
	}
}
Login.propTypes = {
	handleSubmitData: PropTypes.func,
};

export default Login;
