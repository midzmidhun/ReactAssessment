export default {
  apiEndPoints: {
    addData: '/addData',
    getData: '/getData',
  },
  apiBaseUrl: {
    dev: 'http://localhost:8000',
    prod: '',
  },
};
