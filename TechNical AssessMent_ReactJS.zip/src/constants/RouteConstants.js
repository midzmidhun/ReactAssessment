const RouteConstants = {
  REGISTER: '/:register',
  LOGIN: '/:login'
};

export default RouteConstants;
