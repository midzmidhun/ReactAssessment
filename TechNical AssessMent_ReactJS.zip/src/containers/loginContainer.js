import React from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { addData, getData } from '../actionCreators/User';
import Login from '../components/Login';


class LoginContainer extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			loginCompleted: false,
		}
	}
	componentDidMount() {
		this.props.getData();
	}

	// Post the registration form Data//
	submitData = (data) => {
		this.props.addData(data);
		this.setState({
			loginCompleted: true,
		});
	}

	userData = () => {
		const { userData } = this.props;
		const userList = userData && userData.map((item, i) =>
			<li key={i.toString()}>
				Welcome :{item.username}, LastName : {item.lastname};
			</li>
		);
		return (<ul>{userList}</ul>);
	}

	render() {
		const { loginCompleted } = this.state;
		console.log(loginCompleted);
		return (
			<React.Fragment>
				{!loginCompleted ? <Login
					handleSubmitData={(data) => this.submitData(data)}
				/>
					:
					this.userData()
				}
			</React.Fragment>
		);
	}
}

function mapStateToProps(state) {
	const { contactsState } = state;
	const { userData } = contactsState;
	return {
		userData,
	};
}

function mapDispatchToProps(dispatch) {
	return {
		getData: bindActionCreators(getData, dispatch),
		addData: bindActionCreators(addData, dispatch),
	};
}

LoginContainer.propTypes = {
	addData: PropTypes.func,
};

export default connect(mapStateToProps, mapDispatchToProps)(LoginContainer);
