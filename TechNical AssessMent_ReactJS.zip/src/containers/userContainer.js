import React from 'react';
import PropTypes from 'prop-types';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { addData, getData } from '../actionCreators/User';
import Register from '../components/RegistrationForm';


class UserContainer extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			loginPage: false,
		};
	}
	componentDidMount() {
		this.props.getData();
	}

	// Post the registration form Data//
	submitData = (data) => {
		this.props.addData(data);
		this.setState({
			loginPage: true,
		});
	}

	userData = () => {
		const { userData } = this.props;
		const userList = userData && userData.map((item, i) =>
			<li key={i.toString()}>
				Name : {item.name}, Age : {item.age}
			</li>
		);
		return (<ul>{userList}</ul>);
	}

	render() {
		const { login } = this.props.match.params;
		return (
			<React.Fragment>
				<section>
					<Register
						handleSubmitData={(data) => this.submitData(data)}
					/>
				</section>
			</React.Fragment>
		);
	}
}

function mapStateToProps(state) {
	const { contactsState } = state;
	const { userData } = contactsState;
	return {
		userData,
	};
}

function mapDispatchToProps(dispatch) {
	return {
		getData: bindActionCreators(getData, dispatch),
		addData: bindActionCreators(addData, dispatch),
	};
}

UserContainer.propTypes = {
	addData: PropTypes.func,
};

export default connect(mapStateToProps, mapDispatchToProps)(UserContainer);
