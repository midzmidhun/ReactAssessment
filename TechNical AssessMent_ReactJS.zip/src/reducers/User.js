import * as DATA from '../actionTypes/User';

const initialState = {
  user: [],
};

export default (state = initialState, action) => {
  switch (action.type) {
    case DATA.GET_DATA:
      return {
        ...state,
        isLoading: true,
      };
    case DATA.GET_DATA_SUCCESS:
      return {
        ...state,
        isLoading: false,
        userData: action.data,
      };

    case DATA.GET_DATA_FAILURE:
      return {
        ...state,
        isLoading: false,
        error: action.error,
      };
    case DATA.ADD_DATA:
      return {
        ...state,
        isLoading: true,
      };
    case DATA.ADD_DATA_SUCCESS:
      return {
        ...state,
        isLoading: false,
        user: action.contacts,
      };
    case DATA.ADD_DATA_FAILURE:
      return {
        ...state,
        isLoading: false,
        error: action.error,
      };
    default:
      return state;
  }
};
