import { combineReducers } from 'redux';
import user from './User';

const rootReducer = combineReducers({
  contactsState: user,
});

export default rootReducer;
