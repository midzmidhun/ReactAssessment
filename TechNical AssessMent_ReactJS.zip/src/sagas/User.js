import { put, takeLatest } from 'redux-saga/effects';
import envConfig from 'envConfig'; //eslint-disable-line
import * as DATA from '../actionTypes/User';
import * as contactActionCreators from '../actionCreators/User';
import { doGet, doPost } from '../utils/fetchWrapper';

export function* getData() {
  try {
    const response = yield doGet(envConfig.apiEndPoints.getData);
    yield put(contactActionCreators.getDataSuccess(response));
  } catch (error) {
    yield put(contactActionCreators.getContactsFailure(error));
  }
}

export function* addData() {
  try {
    const response = yield doPost(envConfig.apiEndPoints.addData);
    yield put(contactActionCreators.getContactsSucccess(response));
  } catch (error) {
    yield put(contactActionCreators.getContactsFailure(error));
  }
}

export function* contactsWatchers() {
  yield [
    takeLatest(DATA.GET_DATA, getData),
    takeLatest(DATA.ADD_DATA, addData),
  ];
}
