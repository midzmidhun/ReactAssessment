import { contactsWatchers } from './User';

export default function* rootWatchers() {
  yield [
    contactsWatchers(),
  ];
}
